﻿using CYShop.Models;

namespace CYShop.Repositories
{
    public interface ICYShopRepository
    {
        
    }
}
