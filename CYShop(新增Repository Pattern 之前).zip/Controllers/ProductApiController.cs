﻿using CYShop.Data;
using CYShop.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System.Text.Json;

namespace CYShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductApiController : ControllerBase
    {
        private readonly CYShopContext _context;

        public ProductApiController(CYShopContext context)
        {
            _context = context;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<string>> Get(uint id)
        {
            var product = await _context.Products.Select(p => new ProductDTO(p)).FirstOrDefaultAsync(p => p.ID == id);
            if (product == null)
            {
                return NotFound();
            }
            return JsonSerializer.Serialize(product);
        }

        [HttpGet("search/{category}/{searchString?}")]
        public async Task<ActionResult<string>> Get(string category, string? searchString)
        {
            var product = _context.Products.Select(p => p);
            if (category != "All")
            {
                product = product.Where(p => p.ProductCategory.Name == category);
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                product = product.Where(p => p.Name.ToLower().Contains(searchString.ToLower()));
            }
            List<ProductDTO> result = await product.Select(p => new ProductDTO(p)).ToListAsync();
            if (product == null)
            {
                return NotFound();
            }
            return JsonSerializer.Serialize(result);
        }

        [HttpGet]
        public async Task<ActionResult<string>> Get()
        {
            var product = await _context.Products.Select(p => new ProductDTO(p)).ToListAsync();
            if (product == null)
            {
                return NotFound();
            }
            var result = JsonSerializer.Serialize(product);
            return result;
        }
    }
}
