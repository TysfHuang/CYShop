﻿using Microsoft.AspNetCore.Identity;

namespace CYShop.Models
{
    public class CYShopUser : IdentityUser
    {
        //public string City { get; set; }
    }
}
