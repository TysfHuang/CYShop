﻿const productUri = "api/ProductApi";
const pageSize = 10;
const cartList = [];
let currentCategory = "All";
let currentProductList = null;


async function GetFromApiController(targetUri) {
    try {
        const response = await fetch(targetUri);
        if (!response.ok) {
            throw new Error(`Http error: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Could not get products: ${error}`);
    }
}

async function PostToApiController(targetUri, jsonObj) {
    try {
        const response = await fetch(targetUri, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jsonObj)
        });
        if (!response.ok) {
            throw new Error(`Http error: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Could not get products: ${error}`);
    }
}

function ShowLoadingSpinner(flag) {
    if (flag) {
        $("#loadingSpinner").show();
    } else {
        $("#loadingSpinner").hide();
    }
}

function GetAllProducts() {
    return GetFromApiController(productUri);
}

function GetProductsByString(searchString) {
    let targetUri = productUri + '/search/' + currentCategory;
    if (searchString != null) {
        targetUri += '/' + searchString;
    }
    return GetFromApiController(targetUri);
}

function GetProduct(id) {
    let targetUri = productUri + '/' + id.toString();
    return GetFromApiController(targetUri);
}

function GetCartItemObjectFormat(id, name, price, quantity) {
    return {
        ProductID: id,
        ProductName: name,
        Price: price,
        Quantity: quantity
    };
}

function AddToCart(productObj) {
    let targetUri = 'api/CartApi';
    const promise = PostToApiController(targetUri, productObj);
    promise
        .then((data) => {
            if (data != null && data.length > 0) {
                for (let i = 0; i < data.length; i++) {
                    cartList[i] = data[i];
                }
                UpdateCartSummary();
            }
        });
}

function CheckIfShowCheckoutButton() {
    if (cartList.length > 0) {
        $("#cartCheckout").attr("class", "btn btn-primary");
    }
}

function UpdateCartSummary() {
    let quantity = 0;
    let totalPrice = 0;
    for (let i = 0; i < cartList.length; i++) {
        quantity += cartList[i].Quantity;
        totalPrice += cartList[i].Price;
    }
    $("#cartSummary").text("購物車(" + quantity.toString() + ") 總價: $" + totalPrice.toString());
    CheckIfShowCheckoutButton();
}

function GetProductTemplete(id, title, price, imageUrl) {
    let idDiv = $("<p></p>").addClass("visually-hidden").text(id.toString());
    let titleDiv = $("<p></p>").addClass("card-text fs-3").text(title);
    let priceDiv = $("<p></p>").addClass("fw-bold").attr("style", "color:green").text("$" + price.toString());
    let addToCartBtn = $("<button></button>")
        .addClass("btn btn-danger")
        .text("加入購物車")
        .click(function () {
            let productId = $(this).siblings("p.visually-hidden").text();
            let productName = $(this).siblings("p.card-text").text();
            let productPrice = parseInt($(this).siblings("p.fw-bold").text().replace("$", ""));
            AddToCart(GetCartItemObjectFormat(productId, productName, productPrice, 1));
        });
    let imageDiv = $("<img>").attr("src", imageUrl).addClass("rounded float-start");
    let outerDiv = $("<div></div>").addClass("col").attr("max-width", "200px")
        .append($("<div></div>").addClass("card shadow-sm")
            .append($("<div></div>").addClass("card-body")
                .append(idDiv)
                .append(titleDiv)
                .append(priceDiv)
                .append(addToCartBtn))
            .prepend(imageDiv));
    return outerDiv;
}

function SetPaginedList() {
    $("#paginedList").empty();
    let totalPage = Math.ceil(currentProductList.length / pageSize);
    for (let i = 1; i <= totalPage; i++) {
        let button = $("<button></button>").text(i.toString()).click(function () {
            $(this).siblings().attr("class", "btn btn-primary");
            $(this).attr("class", "btn btn-outline-primary disabled");
            SetPageProductList(parseInt($(this).text()));
        });
        if (i == 1) {
            button.attr("class", "btn btn-outline-primary disabled");
        } else {
            button.attr("class", "btn btn-primary");
        }
        $("#paginedList").append(button);
    }
}

function SetProductListAsync(promises) {
    promises.then((data) => {
        currentProductList = data;
        SetPageProductList(1);
        SetPaginedList();   //因非同步所以此函式必須要放這，若放別地方則會取得currentProductList 改變前的數值
    });
}

function SetPageProductList(pageIndex) {
    $("#productList").empty();
    let startIdx = (pageIndex - 1) * pageSize;
    let endIdx = startIdx + pageSize;
    if (currentProductList.length > 0) {
        let productList = $("#productList");
        for (let i = startIdx; i < currentProductList.length && i < endIdx; i++) {
            productList.append(
                GetProductTemplete(
                    currentProductList[i]["ID"],
                    currentProductList[i]["Name"],
                    currentProductList[i]["Price"],
                    '/example.jpg'));
        }
    } else {
        $("#productList").append("<p>沒有搜尋到符合產品</p>");
    }
}

function InitialPage() {
    ShowLoadingSpinner(true);
    let promises = GetAllProducts();
    SetProductListAsync(promises);
    ShowLoadingSpinner(false);
}

function InitialCart() {
    let targetUri = 'api/CartApi';
    let promise = GetFromApiController(targetUri);
    promise.then((data) => {
        if (data != null && data.length > 0) {
            for (let i = 0; i < data.length; i++) {
                cartList[i] = data[i];
            }
            UpdateCartSummary();
        }
    });
}

function SearchProductEvent() {
    ShowLoadingSpinner(true);
    let promises = GetProductsByString($("#searchString").val());
    SetProductListAsync(promises);
    ShowLoadingSpinner(false);
}

function ProductCategoryEvent() {
    ShowLoadingSpinner(true);

    $("#sidebarProductCategory a").attr("class", "nav-link text-white");
    $(this).children("a").attr("class", "nav-link active");

    currentCategory = $(this).text().trim();
    let promises = GetProductsByString();
    SetProductListAsync(promises);

    $("#searchString").val("");
    ShowLoadingSpinner(false);
}

$().ready(function () {
    InitialPage();
    InitialCart();
    $("#searchBtn").click(SearchProductEvent);
    $("#sidebarProductCategory").children().click(ProductCategoryEvent)
});